#include <stdlib.h>
#include <stdio.h>

//1.内存四区：栈区、堆区、静态全局区、代码区
/* 
栈区：存储局部变量，自动申请，自动释放
堆区：手动申请，手动释放
静态全局区：存储static变量和全局变量，内存中只存一份，只初始化一次
代码区：存储函数
*/

/////2.结构体指针
typedef struct student{
    int id;
    char name[5];
}kid,*pstudent;



 
int main()
{
    kid Max={1,"Max"};
    pstudent Pmax=NULL;
    Pmax=&Max;
    printf("%d\n",Max.id);
    
    //结构体指针使用->来访问属性
    printf("%s\n",Pmax->name);
    
    //结构体数组
    kid students[3]={
        {1,"owo"},
        {2,"yey"},
        {3,"ayo"}
    };
    
    printf("%d\n",(students+1)->id);
    
    return(0);
}