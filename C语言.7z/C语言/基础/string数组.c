#include <stdlib.h>
 
int main()
{
    char str[4]="abc";
    printf("%s\n%d\n%c",str,sizeof(str),str[2]);
    return(0);
}