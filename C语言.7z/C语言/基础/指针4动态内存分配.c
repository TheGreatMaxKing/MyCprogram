#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>

//1.内存四区：栈区、堆区、静态全局区、代码区
/* 
栈区：存储局部变量，自动申请，自动释放
堆区：手动申请，手动释放
静态全局区：存储static变量和全局变量，内存中只存一份，只初始化一次
代码区：存储函数
*/

/////2.动态内存分配：从堆区申请内存
//申请内存函数 malloc calloc realloc
//释放内存函数 free

//堆区的内存很大
///


/////3.在函数中申请的堆区内存不会随着函数的结束被自动释放
int *pfunc(){
    int *p=malloc(sizeof(int)*3);
    p[1]=1;
    p[2]=2;
    p[3]=3;
    return p;
}

////
 
int main()
{
    //////1.函数中的堆区内存
    int *w=pfunc();
    for(int i=0;i<3;i++){
        printf("函数中的堆区内存不会自动释放%d\n",w[i]);
    }
    //////
    
    
    //////////2.malloc函数默认返回类型为void 需要进行强制类型转换
    //从堆区申请内存通过指针执行管理
    //申请内存大小以字节为单位
    int *p=(int *)malloc(sizeof(int)*2);
    *p=10;
    *(p+1)=20;
    printf("%d,%d\n",p[1],*p);
    ////////
    
    
    ////////3.realloc重新分配内存，但不会再次进行初始化，可用于数组扩容
    p=realloc(p,sizeof(int)*4);
    for(int i=0;i<40;i++){
        printf("%d\n",p[i]);
    }
    ///////
    
    
    /////////4.calloc申请内存会莫仍初始化为0
    int *q=(int*)calloc(25,sizeof(int));
    //////
    
    ////////5.释放指针,p必须指向释放数组（连续内存块）的首地址
    free(p);
    return(0);
}