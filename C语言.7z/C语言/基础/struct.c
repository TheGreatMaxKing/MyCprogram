#include <stdlib.h>

//结构体别名
typedef struct{
    int id;
    int num[2];
} student;

//若结构体没有别名则直接声明变量p1,p2
struct {
    int id;
    int num;
} p1,p2,p[2];


//嵌套结构
typedef struct{
    int id;
    struct {
        int num;
    } ls;
}ss;

int main()
{
    p1.id=1;
    p1.num=2;
    
    ss s1={1,{2}};
    
    student ken={1,{2}};
    printf("%d",s1.ls.num);
    return(0);
}