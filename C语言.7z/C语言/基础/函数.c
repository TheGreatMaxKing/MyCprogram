#include <stdlib.h>
 
//函数声明
void staticVariable();

//址传递
void point(int *a){
    printf("%d\n",*a);
    *a=*a+*a;
}

//传递数组
void addarry(int a[],int len){
    for(int i=0;i<len;i++){
        printf("%d\n",a[i]);
        a[i]=a[i]+1;
    }
}


//递归
int stage(int a){
    if(a==0){
        return 1;
    }
    return a*stage(a-1);
}

void staticStage(){
    static int a=5;
    a=a-1;
    if(a>1){
        staticStage();
    }
    printf("%d\n",a);
}

void Fei(int a,int b,int len){
    
    if(len<1){
        return;
    }
    
    int c=a+b;
    printf("%d,",c);
    len=len-1;
    Fei(b,c,len);
}

 
int main()
{
    //staticVariable();
    
    //传递和修改指针
    /*
    int a=10;
    point(&a);
    printf("%d\n",a);
    */
    
    //传递数组
    /*int arr[]={1,2,3,4};
    addarry(arr,4);
    printf("%d",arr[0]);*/
    
    //递归
    printf("%d\n",stage(5));
    staticStage();
    Fei(1,1,3);
    
    
    
    return(0);
    
}

void staticVariable(){
    for(int i=1;i<5;i++){
        //！！！static变量只会初始化一次
        static int a=10;
        a++;
        printf("%d\n",a);
    }
}