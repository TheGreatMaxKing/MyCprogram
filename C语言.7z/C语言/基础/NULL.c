#include <stdlib.h>
#include <stdio.h>

int main()
{
    int *a=NULL;
    return 0;
}