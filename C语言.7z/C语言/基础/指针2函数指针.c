#include <stdlib.h>
#include <stdio.h>

/////////1.指针函数：返回值是个函数的指针
int* getAP(){
    //////错误写法，不能把函数体内的局部变量的指针作为返回值
    int a=10;
    return &a;
    /////
}
/////////

/////////2.函数指针
int add(int a,int b){
    return a+b;    
}

int subtract(int a,int b){
    return a-b;
}

//声明函数指针
int (*addP)(int,int);


//函数指针作为参数
void printCount(int (*func)(int,int),int a,int b){
    printf("函数指针作为参数%d\n",func(a,b));
}


//函数指针取别名，别名就是函数名，且可以作为类型使用
typedef int (*twoPint)(int,int);
void printCount2(twoPint func,int a){
    printf("函数指针的别名作类型%d\n",func(a,a));
}

////////


///////3.指针常量，常量指针

//////4.大端存储，小端存储
 
int main()
{
    int *p1=getAP();
    // printf("%d\n",*p1);
 
    
    // 函数指针赋值,加不加&都可，函数名即为指向函数的数组
    addP=&add;
    printf("%d\n",addP(10,10));
    printCount(subtract,10,10);
    printCount2(add,20);
    return(0);
}