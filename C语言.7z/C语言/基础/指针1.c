#include <stdlib.h>
#include <stdio.h>

void point(int arry[]){
    printf("数组指针在函数中的大小%d\n",sizeof(arry));
}

int main()
{
    int a;
    double b;
    char c;
    int *pint=&a;
    int *pd=&b;
    int *pc=&c;
 
    ///////////知识点1 不管是什么类型的指针变量，其大小都是固定的   
    printf("%d\n%d\n%d\n",sizeof(pint),sizeof(pd),sizeof(pc));
    //////////
    
    /////////知识点2 数组指针
    int arr[10]={1,2,3,4,5,6,7,8,9,10};
    
    printf("数组指针的大小%d\n",sizeof(arr));
    point(arr);
    
    // 2.1数组名也是指针
    printf("%d,%d\n",arr,&arr[0]);
    
    // 2.2显示数组指针，数组当中的元素在内存中连续
    for(int i=0;i<10;i++){
        printf("%d\n",&arr[i]);
    }
    
    // 2.3通过指针访问数组 指针偏移
    printf("数组指针访问数组%d,%d\n",*arr,*arr+1);
    
    //2.4指针类型强制转换
    double * darr=(double*)arr;
    darr++;
    printf("指针类型转换%d\n",*((int*)(darr)));
    
    
    
    ////////
    return 0;
}