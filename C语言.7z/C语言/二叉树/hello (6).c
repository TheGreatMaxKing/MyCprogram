#include <stdlib.h>


#include <stdbool.h>
 
typedef struct BiTNode{
    int data;
    struct BiTNode *lchild,*rchild;
}BiTNode,*Bitree;

void PreOrder(Bitree node){
    if(node==NULL){
        return;
    }
    // printf("%d\n",node->data);
    PreOrder(node->lchild);
    printf("%d\n",node->data);
    PreOrder(node->rchild);
    //printf("%d\n",node->data);
} 

//找中序前驱
BiTNode* findMiddlePre(Bitree node,BiTNode* goal,BiTNode* parent){
    if(node==NULL){
        return;
    }
    findMiddlePre(node->lchild,goal,parent);
    if(node==goal){
        printf("结点%d的前驱为%d\n",node->data,parent->data);
        return parent; 
    }
    findMiddlePre(node->rchild,goal,node);
}

int GetDepth(Bitree node){
    if(node==NULL){
        return 0;
    }
    int l=GetDepth(node->lchild);
    int r=GetDepth(node->rchild);
    return (l>r?l:r)+1;
}

int GetNodeNums(Bitree node){
    if(node==NULL){
        return 0;
    }
    int l=GetNodeNums(node->lchild);
    int r=GetNodeNums(node->rchild);
    return l+r+1;
}

int GetNodeLeafNums(Bitree node){
    if(node==NULL){
        return 0;
    }
    if(node->lchild==NULL&&node->rchild==NULL){
        return 1;
    }
    int l=GetNodeLeafNums(node->lchild);
    int r=GetNodeLeafNums(node->rchild);
    return l+r;
}

 
int main()
{
    printf("Hello, World\n");
    
    Bitree root=(Bitree)malloc(sizeof(BiTNode));
    root->data=0;
    root->lchild=NULL;
    root->rchild=NULL;
    
    BiTNode* node1=(BiTNode*)malloc(sizeof(BiTNode));
    node1->data=1;
    node1->lchild=NULL;
    node1->rchild=NULL;
    root->lchild=node1;
    
    BiTNode* node2=(BiTNode*)malloc(sizeof(BiTNode));
    node2->data=2;
    node2->lchild=NULL;
    node2->rchild=NULL;
    root->rchild=node2;
    
    BiTNode* node3=(BiTNode*)malloc(sizeof(BiTNode));
    node3->data=3;
    node3->lchild=NULL;
    node3->rchild=NULL;
    node1->lchild=node3;
    
    BiTNode* node4=(BiTNode*)malloc(sizeof(BiTNode));
    node4->data=4;
    node4->lchild=NULL;
    node4->rchild=NULL;
    node1->rchild=node4;
    
    BiTNode* node5=(BiTNode*)malloc(sizeof(BiTNode));
    node5->data=5;
    node5->lchild=NULL;
    node5->rchild=NULL;
    node3->lchild=node5;
    
    
    PreOrder(root);
    
    int depth=GetDepth(root);
    
    printf("树高%d\n结点数%d\n叶子结点数%d\n",depth,GetNodeNums(root),GetNodeLeafNums(root));
    
    // findMiddlePre(root,node1,(BiTNode*)NULL);
    
    findMiddlePre(root,node3,root);
    
    return(0);
}