#include <stdlib.h>
 
int partition(int a[],int low,int high){
    int tmp=a[low];
    while(low<high){
        while(a[high]>=tmp&&high>low){
            high--;
        }
        a[low]=a[high];
        
        while(a[low]<=tmp&&high>low){
            low++;
        }
        
        a[high]=a[low];
    }
    a[low]=tmp;
    return low;
} 

void QuikSort(int a[],int low,int high){
    if(low>=high){
        return;
    }
    int middle=partition(a,low,high);
    QuikSort(a,low,middle-1);
    QuikSort(a,middle+1,high);
}

void printList(int a[],int length){
    for(int i=0;i<length;i++){
        printf("%d ",a[i]);
    }
}
 
int main()
{
    int a[]={1,3,2,1,4,6,2,1,3,7,1,2};
    int l=sizeof(a)/sizeof(a[0]);
    //printf("%d",l);
    QuikSort(a,0,l-1);
    
    printList(a,l);
    
    return(0);
}