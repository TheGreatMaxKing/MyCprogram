#include <stdlib.h>
 
void ShellSortt(int A[],int l,int d){
    int tmp;
    
    for(int di=d;di>=1;di=di/2){
        printf("%d\n",di);
        for(int i=1;i<l;i++){
            tmp=A[i];
            for(int j=i-di;;j--){
                if(j<0){
                    break;
                }
                if(A[j]<=tmp){
                    A[j+di]=tmp;
                    break;
                }else{
                    A[j+di]=A[j];
                }
                if(j==0){
                    A[0]=tmp;
                    break;
                }
            }
        }
    }
}

void printList(int A[],int l){
    for(int i=0;i<l;i++){
        printf("%d ",A[i]);
    }
}
 
int main()
{
    int A[]={7,2,2,11,3,22,4,1,1,5};
    int l=sizeof(A)/sizeof(A[0]);
    ShellSortt(A,l,4);
    printList(A,l);
    return(0);
}