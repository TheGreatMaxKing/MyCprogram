#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

typedef struct Lnode{
    int data;
    struct Lnode* next;
}Lnode,*LinkList;

_Bool test(){
    return true;
}

//初始不带头结点的化单链表
_Bool InitList(LinkList L){
    L=NULL;
    return 1;
}

int main()
{
    LinkList LnoHead;
    InitList(LnoHead);
    
    printf("Hello, World");
    return(0);
}