#include <stdlib.h>

#define Maxsize 10

typedef int Status;

typedef struct A{
    int datas[10];
    int length;
}ST;

void initial(ST *la){
    la->length=0;
}

_Bool insert(ST* a,int id,int e){
    if(id>Maxsize){
        return 0;
    }    
    if(id>a->length+1||id<1){
        return 0;
    }
    for(int i=a->length;i>=id;i--){
        a->datas[i]=a->datas[i-1];
    }
    a->datas[id-1]=e;
    a->length++;
    //printf("%d",a->length);
    return 1;
}

_Bool delete(ST *al,int id,int *e){
    if(id>Maxsize){
        return 0;
    }
    if(id<1||id>al->length){
        return 0;
    }
    *e=al->datas[id-1];
    for(int i=id;i<al->length;i++){
        al->datas[i-1]=al->datas[i];
    }
    al->length--;
    return 1;
    
}

_Bool searchByID(ST al,int id,int* e){
    if(id<1||id>al.length){
        return 0;
    }
    *e=al.datas[id-1];
    return 1;
}

_Bool searchByValue(ST al,int a,int* e){
    
}

void printDatas(ST a){
    printf("line:");
    for(int i=0;i<a.length;i++){
        printf("%d,",a.datas[i]);
    }
    printf("\n");
}


int main()
{
    ST line;
    initial(&line);
    
    insert(&line,1,1);
    insert(&line,1,2);
    
    printDatas(line);
    
    int de;
    delete(&line,1,&de);
    
    int findID;
    searchByID(line,1,&findID);
    printf("\nfindID,%d\n",findID);
    
    printDatas(line);
    
    printf("\n%d",de);
    return(0);
}