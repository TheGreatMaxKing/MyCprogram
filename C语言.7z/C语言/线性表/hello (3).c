#include <stdlib.h>

//10
_Bool circleList(int *list,int p,int length){
    if(p>=length||p<=0){
        return 0;
    }
    if(length<=1){
        return 0;
    }
    int id=0;
    int tmp=list[0],tmp1;
    for(;;){
        tmp1=list[id];
        list[id]=tmp;
        id=(id+p)%length;
        tmp=tmp1;
        if(id==0){
            list[id]=tmp;
            break;
        }
    }
    return 1;
}

int main()
{   
    int list[5]={1,2,3,4,5};
    circleList(list,4,5);
    for(int i=0;i<5;i++){
     printf("%d,",list[i]);   
    }
    return(0);
}