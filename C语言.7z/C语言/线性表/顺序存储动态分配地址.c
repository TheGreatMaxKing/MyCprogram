#include <stdlib.h>

typedef struct {
    int* datas;
    int length;
    int maxSize;
}SLlist;

void initial(SLlist *sl,int maxSize){
    int* temp=(int*)malloc(maxSize * sizeof(int));
    if(temp==NULL){
        perror(malloc);
		exit(-1);
    }
    sl->datas=temp;
    sl->length=0;
    sl->maxSize=maxSize;
    
}

_Bool insert(SLlist *sl,int id,int e){
    if(id>sl->maxSize){
        return 0;
    }
    if(id<1||id>sl->length+1){
        return 0;
    }
    
    for(int i=sl->length;i>id;i--){
        sl->datas[i]=sl->datas[i-1];
    }
    sl->datas[id-1]=e;
    sl->length++;
    return 1;
}

void printDatas(SLlist sl){
    printf("\ndatas:");
    for(int i=0;i<sl.length;i++){
        printf("%d,",sl.datas[i]);
    }
}

int main()
{
    SLlist sl;
    
    initial(&sl,5);
    
    printf("%d",sl.length);
    
    insert(&sl,1,1);
    
    printf("%d",sl.length);
    
    insert(&sl,1,2);
    
    printDatas(sl);
    
    return(0);
}