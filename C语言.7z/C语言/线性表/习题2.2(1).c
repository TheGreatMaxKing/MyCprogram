#include <stdlib.h>

#define InitSize 10

typedef struct{
    int* datas;
    int MaxSize,length;
} SeqList;

void initial(SeqList* seq){
    seq->datas=(int*)malloc(sizeof(int)*InitSize);
    seq->length=0;
    seq->MaxSize=InitSize;
}

void initial2(SeqList* seq,int maxSize){
    seq->datas=(int*)malloc(sizeof(int)*maxSize);
    seq->length=0;
    seq->MaxSize=maxSize;
}

_Bool insertInLast(SeqList* seq,int e){
    if(seq->length>=seq->MaxSize){
        return 0;
    }
    seq->datas[seq->length]=e;
    seq->length++;
}


_Bool deleteMin(SeqList* seq,int* minElement){
    if(seq->length==0){
        return 0;
    }
    int min=seq->datas[0];
    printf("MM%dMM\n",seq->datas[0]);
    int id=0;
    
    for(int i=0;i<seq->length;i++){
        if(seq->datas[i]<min){
            min=seq->datas[i];
            id=i;
        }
    }
    printf("MM%dMM\n",min);
    *minElement=min;
    seq->datas[id]=seq->datas[seq->length-1];
    seq->length--;
    
    return 1;
}

//删除所有的E
_Bool deleteAllE(SeqList* L,int e){
    int length=L->length;
    if(length==0){
        return 0;
    }
    int delNum=0;
    for(int i=0;i<length;i++){
        if(L->datas[i]==e){
            delNum=delNum+1;
        }
        else{
            L->datas[i-delNum]=L->datas[i];
        }
    }
    L->length=L->length-delNum;
    return 1;
}

//删除所有st之间的值
_Bool deleteBetweenSandT(SeqList* L,int s,int t){
    if(s>=t){
        return 0;
    }
    int length=L->length;
    if(length==0){
        return 0;
    }
    
    int k=0;
    
    for(int i=0;i<length;i++){
        if(L->datas[i]>t||L->datas[i]<s){
            L->datas[k]=L->datas[i];
            k++;
        }    
    }
    L->length=k;
    
    return 1;
}

//6.
_Bool uniqueSeries(SeqList *L){
    int temps[L->length];
    int tempsLength=0;
    int k=0;
    int tid=0;
    for(int i=0;i<L->length;i++){
        tid=0;
        for(;tid<tempsLength;){
            printf("INF%d\n",temps[tid]);
            if(L->datas[i]==temps[tid]){
                printf("%d\n",L->datas[i]);
                break;
            }
            tid=tid+1;
        }
        if(tid==tempsLength){
            temps[tempsLength]=L->datas[i];
            tempsLength++;
            printf("E%dL%d\n",L->datas[i],tempsLength);
            L->datas[k]==L->datas[i];
            k++;
        }
    }
    L->length=k;
    return 1;
}


//7.
_Bool twoSeries(SeqList L1,SeqList L2,SeqList* Lresult){
    if(Lresult->MaxSize<(L1.length+L2.length)){
        printf("HHH");
        return 0;
    }
    int id1=0,id2=0,idr=0;
    for(;;){
        if(id1==L1.length){
            for(int i=id2;i<L2.length;i++){
                Lresult->datas[idr]=L2.datas[i];
                idr++;
            }
            break;
        }
        
        if(id2==L2.length){
            for(int i=id1;i<L1.length;i++){
                Lresult->datas[idr]=L1.datas[i];
                idr++;
            }
            break;
        }
        
        if(L1.datas[id1]<L2.datas[id2]){
            Lresult->datas[idr]=L1.datas[id1];
            printf("\nL1:%d",L1.datas[id1]);
            id1++;
        }else{
            Lresult->datas[idr]=L2.datas[id2];
            printf("\nL2:%d",L2.datas[id2]);
            id2++;
        }
        idr++;
    }
    Lresult->length=idr;
    
    return 1;
}

void printDatas(SeqList L){
    printf("\nLIST:");
    for(int i=0;i<L.length;i++){
        printf("%d,",L.datas[i]);    
    }
    printf("\n");
}

//8.
_Bool changeMN(SeqList *L,int m,int n){
    if(m<0||n<0){
        return 0;
    }
    if(L->length!=m+n||L->length==0){
        return 0;
    }
    int tmp=L->datas[0],tmp2;
    int id=0;
    for(;;){
        if(id<m){
            tmp2=L->datas[id];
            L->datas[id]=tmp;
            tmp=tmp2;
            id=id+n;
        }else{
            tmp2=L->datas[id];
            L->datas[id]=tmp;
            tmp=tmp2;
            id=id-m;
        }
        if(id==0){
            L->datas[id]=tmp;
            break;
        }
    }
    return 1;
}





int main()
{
    SeqList L;
    initial(&L);
    insertInLast(&L,1);
    insertInLast(&L,1);
    insertInLast(&L,2);
    insertInLast(&L,6);
    insertInLast(&L,8);
    printDatas(L);
    
    SeqList L2;
    initial(&L2);
    insertInLast(&L2,1);
    insertInLast(&L2,4);
    insertInLast(&L2,6);
    insertInLast(&L2,7);
    //printDatas(L2);
    
    SeqList LR;
    initial2(&LR,9);
    //printf("%d",LR.MaxSize);
    //deleteAllE(&L,2);
    //deleteBetweenSandT(&L,1,2);
    //uniqueSeries(&L);
    //twoSeries(L,L2,&LR);
    
    changeMN(&L,1,4);
    printDatas(L);
    
    return(0);
}